import type { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface GlassmorphismCardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
}

export function GlassmorphismCard({ children, className = '', hover = true }: GlassmorphismCardProps) {
  return (
    <div
      className={cn(
        'glassmorphism rounded-2xl p-8 transition-all duration-400',
        hover && 'hover:border-violet/30 hover:-translate-y-1 hover:shadow-card',
        className
      )}
    >
      {children}
    </div>
  );
}
