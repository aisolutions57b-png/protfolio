import { useRef, useEffect } from 'react';
import type { ReactNode } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { useReducedMotion } from '@/hooks/useReducedMotion';

gsap.registerPlugin(ScrollTrigger);

interface ScrollRevealProps {
  children: ReactNode;
  className?: string;
  variant?: 'default' | 'card' | 'badge' | 'timeline-left' | 'timeline-right';
  delay?: number;
  stagger?: number;
}

export function ScrollReveal({
  children,
  className = '',
  variant = 'default',
  delay = 0,
  stagger = 0,
}: ScrollRevealProps) {
  const ref = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    if (reducedMotion || !ref.current) return;

    const el = ref.current;
    const childElements = stagger > 0 ? el.children : [el];

    let fromVars: gsap.TweenVars = { opacity: 0, y: 30 };
    let toVars: gsap.TweenVars = {
      opacity: 1,
      y: 0,
      duration: 0.8,
      ease: 'power3.out',
      delay,
      stagger: stagger > 0 ? stagger : 0,
      scrollTrigger: {
        trigger: el,
        start: 'top 80%',
        toggleActions: 'play none none none',
      },
    };

    switch (variant) {
      case 'card':
        fromVars = { opacity: 0, y: 40, scale: 0.95 };
        toVars = {
          ...toVars,
          duration: 0.6,
          ease: 'power2.out',
          scale: 1,
        };
        break;
      case 'badge':
        fromVars = { opacity: 0, y: 20 };
        toVars = { ...toVars, duration: 0.5 };
        break;
      case 'timeline-left':
        fromVars = { opacity: 0, x: -30 };
        toVars = { ...toVars, duration: 0.7, x: 0 };
        break;
      case 'timeline-right':
        fromVars = { opacity: 0, x: 30 };
        toVars = { ...toVars, duration: 0.7, x: 0 };
        break;
    }

    gsap.fromTo(childElements, fromVars, toVars);

    return () => {
      ScrollTrigger.getAll().forEach((st) => {
        if (st.trigger === el) st.kill();
      });
    };
  }, [reducedMotion, variant, delay, stagger]);

  if (reducedMotion) {
    return <div className={className}>{children}</div>;
  }

  return (
    <div ref={ref} className={className}>
      {children}
    </div>
  );
}
