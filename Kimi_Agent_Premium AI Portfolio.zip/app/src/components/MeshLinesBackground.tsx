import { useRef, useEffect } from 'react';
import * as THREE from 'three';
import { MeshLineGeometry, MeshLineMaterial } from 'meshline';
import { useReducedMotion } from '@/hooks/useReducedMotion';

const COLORS = ['#6C63FF', '#00D4FF', '#F0F2F5', '#6C63FF', '#00D4FF', '#F0F2F5'];

interface LineData {
  mesh: THREE.Mesh;
  material: MeshLineMaterial;
  points: THREE.Vector3[];
  speed: number;
  length: number;
  maxLength: number;
  growing: boolean;
}

function randomFloat(min: number, max: number) {
  return Math.random() * (max - min) + min;
}

function getRandomColor() {
  return COLORS[Math.floor(Math.random() * COLORS.length)];
}

export function MeshLinesBackground() {
  const containerRef = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    if (reducedMotion || !containerRef.current) return;

    const container = containerRef.current;
    let width = container.clientWidth;
    let height = container.clientHeight;

    // Scene setup
    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(50, width / height, 0.1, 1000);
    camera.position.set(0, 0, 10);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(1.6, window.devicePixelRatio));
    renderer.setClearColor(0x0b0f19, 1);
    container.appendChild(renderer.domElement);

    // Lines array
    const lines: LineData[] = [];
    const maxLines = width < 768 ? 25 : 50;
    const spawnRate = width < 768 ? 0.25 : 0.15;
    let spawnTimer = 0;

    // Create a new line
    function createLine() {
      if (lines.length >= maxLines) return;

      const points: THREE.Vector3[] = [];
      const startX = randomFloat(-8, 8);
      const startY = randomFloat(-5, 5);
      const startZ = randomFloat(-3, 3);
      const startPoint = new THREE.Vector3(startX, startY, startZ);
      points.push(startPoint.clone());

      // Create initial segment
      const dirX = randomFloat(-0.5, 0.5);
      const dirY = randomFloat(-0.5, 0.5);
      const dirZ = randomFloat(-0.1, 0.1);
      points.push(startPoint.clone().add(new THREE.Vector3(dirX, dirY, dirZ)));

      const geometry = new MeshLineGeometry();
      geometry.setPoints(points.map((p) => [p.x, p.y, p.z]).flat());

      const color = new THREE.Color(getRandomColor());
      const dashArray = 2;
      const dashRatio = 0.99;
      const dashOffset = 0;

      const material = new MeshLineMaterial({
        lineWidth: randomFloat(0.02, 0.06),
        dashArray,
        dashRatio,
        dashOffset,
        opacity: 0.4,
        color,
        resolution: new THREE.Vector2(width, height),
      });
      material.transparent = true;
      material.depthWrite = false;

      const mesh = new THREE.Mesh(geometry, material);
      scene.add(mesh);

      lines.push({
        mesh,
        material,
        points,
        speed: randomFloat(0.01, 0.03),
        length: 2,
        maxLength: Math.floor(randomFloat(8, 20)),
        growing: true,
      });
    }

    // Update a line
    function updateLine(line: LineData): boolean {
      if (line.growing) {
        // Add new point
        const lastPoint = line.points[line.points.length - 1];
        const newX = lastPoint.x + randomFloat(-0.5, 0.5);
        const newY = lastPoint.y + randomFloat(-0.5, 0.5);
        const newZ = lastPoint.z + randomFloat(-0.1, 0.1);
        line.points.push(new THREE.Vector3(newX, newY, newZ));
        line.length++;

        if (line.length >= line.maxLength) {
          line.growing = false;
        }

        // Update geometry
        const geometry = line.mesh.geometry as MeshLineGeometry;
        geometry.setPoints(line.points.map((p) => [p.x, p.y, p.z]).flat());
      }

      // Move line forward
      const direction = new THREE.Vector3(0, 0, 1);
      direction.applyQuaternion(line.mesh.quaternion);
      line.mesh.position.add(direction.multiplyScalar(line.speed * 0.5));

      // Animate dash offset
      line.material.dashOffset -= line.speed * 0.3;

      // Check if line is dead
      return line.material.dashOffset > -1;
    }

    // Animation loop
    let animationId: number;
    let lastTime = 0;

    function animate(time: number) {
      animationId = requestAnimationFrame(animate);

      const delta = (time - lastTime) / 1000;
      lastTime = time;

      // Spawn new lines
      spawnTimer += delta;
      if (spawnTimer > spawnRate) {
        createLine();
        spawnTimer = 0;
      }

      // Update lines
      for (let i = lines.length - 1; i >= 0; i--) {
        const alive = updateLine(lines[i]);
        if (!alive) {
          scene.remove(lines[i].mesh);
          lines[i].mesh.geometry.dispose();
          (lines[i].mesh.material as THREE.Material).dispose();
          lines.splice(i, 1);
        }
      }

      renderer.render(scene, camera);
    }

    // Start animation
    animationId = requestAnimationFrame(animate);

    // Handle resize
    const handleResize = () => {
      if (!container) return;
      width = container.clientWidth;
      height = container.clientHeight;
      camera.aspect = width / height;
      camera.updateProjectionMatrix();
      renderer.setSize(width, height);

      // Update resolution for all materials
      lines.forEach((line) => {
        line.material.resolution.set(width, height);
      });
    };

    window.addEventListener('resize', handleResize);

    // Cleanup
    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener('resize', handleResize);

      lines.forEach((line) => {
        scene.remove(line.mesh);
        line.mesh.geometry.dispose();
        (line.mesh.material as THREE.Material).dispose();
      });
      lines.length = 0;

      renderer.dispose();
      if (container.contains(renderer.domElement)) {
        container.removeChild(renderer.domElement);
      }
    };
  }, [reducedMotion]);

  if (reducedMotion) {
    return (
      <div
        className="absolute inset-0 z-0"
        style={{ background: '#0B0F19' }}
      />
    );
  }

  return (
    <div
      ref={containerRef}
      className="absolute inset-0 z-0"
      style={{ background: '#0B0F19' }}
    />
  );
}
