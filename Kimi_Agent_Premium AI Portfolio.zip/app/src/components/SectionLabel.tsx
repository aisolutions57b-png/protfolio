interface SectionLabelProps {
  text: string;
  centered?: boolean;
}

export function SectionLabel({ text, centered = false }: SectionLabelProps) {
  return (
    <div className={`flex items-center gap-3 mb-4 ${centered ? 'justify-center' : ''}`}>
      <div className="w-5 h-0.5 bg-violet rounded-full" />
      <span className="text-xs font-medium uppercase tracking-[0.12em] text-violet">
        {text}
      </span>
    </div>
  );
}
