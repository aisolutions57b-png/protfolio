import { Navigation } from '@/sections/Navigation';
import { Hero } from '@/sections/Hero';
import { About } from '@/sections/About';
import { Skills } from '@/sections/Skills';
import { Tools } from '@/sections/Tools';
import { Projects } from '@/sections/Projects';
import { Process } from '@/sections/Process';
import { Contact } from '@/sections/Contact';
import { Footer } from '@/sections/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-bg">
      <Navigation />
      <main>
        <Hero />
        <About />
        <Skills />
        <Tools />
        <Projects />
        <Process />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}
