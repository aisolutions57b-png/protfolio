import { ExternalLink, CheckCircle } from 'lucide-react';
import { SectionLabel } from '@/components/SectionLabel';
import { GradientText } from '@/components/GradientText';
import { ScrollReveal } from '@/components/ScrollReveal';

const projects = [
  {
    name: 'SmartDental AI',
    description:
      'Customer Support & Appointment Booking System for Dental Clinics',
    outcomes: [
      'Instant patient responses',
      'Automated appointment scheduling',
      'Reduced front desk workload',
      'Improved patient experience',
    ],
    demoUrl:
      'https://drive.google.com/file/d/1NPV5gZlhvOzdO_5r0PXNKtojok1Oxd34/view',
  },
  {
    name: 'MedSpaFlow AI',
    description:
      'Customer Support & Appointment Booking System for MedSpa Clinics',
    outcomes: [
      '24/7 customer engagement',
      'Automated consultation booking',
      'Faster lead conversion',
      'Reduced administrative work',
    ],
    demoUrl:
      'https://drive.google.com/file/d/1mS_t00GL9U5CnuIcPGAT_G0wNi5WdMp_/view',
  },
  {
    name: 'InstaLead Engine',
    description: 'Instagram Lead Scraper & Lead Generation System',
    outcomes: [
      'Automated lead sourcing',
      'Eliminated manual prospecting',
      'Faster lead generation',
      'Organized outreach-ready data',
    ],
    demoUrl:
      'https://drive.google.com/file/d/1ninEr7gc0fspZrj0cyRxCZ65m-7SfJqd/view?usp=sharing',
  },
  {
    name: 'EstateFlow AI',
    description:
      'Real Estate Lead Qualification & Property Recommendation System',
    outcomes: [
      'Automated lead qualification',
      'Personalized property recommendations',
      'Automated appointment scheduling',
      'Faster response times',
    ],
    demoUrl:
      'https://drive.google.com/file/d/1Whd9LupeNWOPXuusxLeRsSDsplJMCqi-/view',
  },
  {
    name: 'SalonSync AI',
    description: 'Salon Appointment Booking & Customer Management System',
    outcomes: [
      'Automated booking process',
      'Reduced scheduling conflicts',
      'Improved customer experience',
      'Less manual coordination',
    ],
    demoUrl:
      'https://drive.google.com/file/d/10H2ZS_FRi99dmK_CnmYsSaS-6qZy2Df7/view',
  },
];

function ProjectCard({
  project,
}: {
  project: (typeof projects)[0];
}) {
  return (
    <div className="group relative glassmorphism rounded-2xl overflow-hidden transition-all duration-400 hover:-translate-y-2 hover:shadow-card-hover hover:border-violet/30">
      {/* Top accent bar */}
      <div className="h-1 w-full bg-gradient-to-r from-violet via-violet-light to-cyan animate-shimmer" />

      <div className="p-7">
        {/* Project Name */}
        <h3 className="text-xl font-semibold text-text-primary mb-2">
          {project.name}
        </h3>

        {/* Description */}
        <p className="text-sm text-text-secondary leading-relaxed mb-5">
          {project.description}
        </p>

        {/* Outcomes */}
        <ul className="space-y-2 mb-6">
          {project.outcomes.map((outcome) => (
            <li key={outcome} className="flex items-start gap-2.5">
              <CheckCircle
                size={16}
                className="text-violet mt-0.5 flex-shrink-0"
              />
              <span className="text-sm text-text-secondary">{outcome}</span>
            </li>
          ))}
        </ul>

        {/* Demo Button */}
        <a
          href={project.demoUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center justify-center gap-2 w-full py-3 bg-violet hover:bg-violet-light text-white text-xs font-medium uppercase tracking-[0.08em] rounded-lg transition-all duration-300 hover:shadow-glow-violet"
        >
          <span>View Demo</span>
          <ExternalLink size={14} />
        </a>
      </div>
    </div>
  );
}

export function Projects() {
  return (
    <section
      id="projects"
      className="relative py-24 lg:py-32"
      style={{
        background:
          'linear-gradient(180deg, #0E1420 0%, #0B0F19 50%, #0E1420 100%)',
      }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <ScrollReveal className="text-center mb-16" variant="default">
          <SectionLabel text="Portfolio" centered />
          <h2 className="text-4xl lg:text-5xl font-bold text-text-primary">
            <GradientText>Featured</GradientText> Projects
          </h2>
        </ScrollReveal>

        {/* Projects Grid - First row: 2 cards */}
        <ScrollReveal variant="card" stagger={0.15}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-7 mb-7">
            {projects.slice(0, 2).map((project) => (
              <ProjectCard key={project.name} project={project} />
            ))}
          </div>
        </ScrollReveal>

        {/* Projects Grid - Second row: 3 cards */}
        <ScrollReveal variant="card" stagger={0.15}>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-7">
            {projects.slice(2).map((project) => (
              <ProjectCard key={project.name} project={project} />
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
