import { Phone, Mail } from 'lucide-react';
import { SectionLabel } from '@/components/SectionLabel';
import { GradientText } from '@/components/GradientText';
import { ScrollReveal } from '@/components/ScrollReveal';

export function Contact() {
  return (
    <section
      id="contact"
      className="relative py-32 lg:py-40 overflow-hidden"
      style={{
        background:
          'linear-gradient(180deg, #0E1420 0%, #0B0F19 100%)',
      }}
    >
      {/* Decorative glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none animate-contact-glow"
        style={{
          width: '600px',
          height: '400px',
          background:
            'radial-gradient(ellipse 600px 400px at 50% 50%, rgba(108, 99, 255, 0.08) 0%, transparent 70%)',
        }}
      />

      <div className="relative z-10 max-w-[800px] mx-auto px-6 text-center">
        <ScrollReveal variant="default">
          <SectionLabel text="Get in Touch" centered />
        </ScrollReveal>

        <ScrollReveal variant="default" delay={0.1}>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight">
            <GradientText>Maheen Ansari</GradientText>
          </h1>
        </ScrollReveal>

        <ScrollReveal variant="default" delay={0.2}>
          <p className="mt-4 text-xl text-text-secondary font-medium">
            AI Automation Specialist
          </p>
        </ScrollReveal>

        <ScrollReveal variant="default" delay={0.3}>
          <div className="w-20 h-px bg-border-subtle mx-auto my-10" />
        </ScrollReveal>

        <ScrollReveal variant="default" delay={0.4}>
          <div className="space-y-3">
            <a
              href="tel:+923113092636"
              className="flex items-center justify-center gap-3 text-text-primary hover:text-violet transition-colors duration-300 group"
            >
              <Phone size={18} className="text-violet" />
              <span className="text-lg">+92 311 3092636</span>
            </a>
            <a
              href="mailto:aisolutions@gmail.com"
              className="flex items-center justify-center gap-3 text-text-primary hover:text-violet transition-colors duration-300 group"
            >
              <Mail size={18} className="text-violet" />
              <span className="text-lg">aisolutions@gmail.com</span>
            </a>
          </div>
        </ScrollReveal>

        <ScrollReveal variant="default" delay={0.5}>
          <div className="flex flex-wrap justify-center gap-4 mt-12">
            <a
              href="tel:+923113092636"
              className="flex items-center gap-2 px-7 py-3.5 bg-violet hover:bg-violet-light text-white text-xs font-medium uppercase tracking-[0.08em] rounded-lg transition-all duration-300 hover:shadow-glow-violet hover:scale-[1.02]"
            >
              <Phone size={14} />
              Call Now
            </a>
            <a
              href="mailto:aisolutions@gmail.com"
              className="flex items-center gap-2 px-7 py-3.5 border border-border-subtle hover:border-violet text-text-primary hover:text-white hover:bg-violet/5 text-xs font-medium uppercase tracking-[0.08em] rounded-lg transition-all duration-300 hover:scale-[1.02]"
            >
              <Mail size={14} />
              Send Email
            </a>
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
