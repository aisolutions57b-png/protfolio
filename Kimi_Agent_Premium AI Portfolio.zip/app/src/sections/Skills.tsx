import { Lightbulb, Cpu, Workflow, TrendingUp, MessageSquare, Network } from 'lucide-react';
import { SectionLabel } from '@/components/SectionLabel';
import { GradientText } from '@/components/GradientText';
import { GlassmorphismCard } from '@/components/GlassmorphismCard';
import { ScrollReveal } from '@/components/ScrollReveal';

const skills = [
  {
    icon: Lightbulb,
    title: 'Problem Solving',
    description:
      'Identifying inefficiencies and designing strategic solutions that address core business challenges',
  },
  {
    icon: Cpu,
    title: 'AI Automation',
    description:
      'Building intelligent systems that replace manual processes with automated, AI-driven workflows',
  },
  {
    icon: Workflow,
    title: 'Workflow Design',
    description:
      'Creating seamless, end-to-end automation flows that connect tools and eliminate friction',
  },
  {
    icon: TrendingUp,
    title: 'Business Process Optimization',
    description:
      'Analyzing and refining operations to maximize productivity and reduce operational costs',
  },
  {
    icon: MessageSquare,
    title: 'AI Chatbot Development',
    description:
      'Designing conversational AI agents that handle customer interactions 24/7 with human-like precision',
  },
  {
    icon: Network,
    title: 'Multi-Workflow & AI Infrastructure',
    description:
      'Architecting complex, interconnected automation systems that scale with your business',
  },
];

export function Skills() {
  return (
    <section
      id="skills"
      className="relative py-24 lg:py-32"
      style={{
        background: 'linear-gradient(180deg, #0B0F19 0%, #0E1420 100%)',
      }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Header */}
        <ScrollReveal className="text-center mb-16" variant="default">
          <SectionLabel text="Expertise" centered />
          <h2 className="text-4xl lg:text-5xl font-bold text-text-primary">
            Skills <GradientText>& Expertise</GradientText>
          </h2>
        </ScrollReveal>

        {/* Skills Grid */}
        <ScrollReveal variant="card" stagger={0.12}>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {skills.map((skill) => (
              <GlassmorphismCard key={skill.title} className="h-full">
                <skill.icon
                  size={48}
                  strokeWidth={1.5}
                  className="text-violet mb-5"
                />
                <h3 className="text-xl font-semibold text-text-primary">
                  {skill.title}
                </h3>
                <p className="mt-3 text-sm text-text-secondary leading-relaxed">
                  {skill.description}
                </p>
              </GlassmorphismCard>
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
