import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { MeshLinesBackground } from '@/components/MeshLinesBackground';
import { SectionLabel } from '@/components/SectionLabel';
import { GradientText } from '@/components/GradientText';
import { useReducedMotion } from '@/hooks/useReducedMotion';

export function Hero() {
  const contentRef = useRef<HTMLDivElement>(null);
  const photoRef = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    if (reducedMotion || !contentRef.current || !photoRef.current) return;

    const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

    tl.fromTo(
      contentRef.current.querySelectorAll('.hero-animate'),
      { opacity: 0, y: 30 },
      { opacity: 1, y: 0, duration: 1, stagger: 0.15 }
    ).fromTo(
      photoRef.current,
      { opacity: 0, scale: 0.9 },
      { opacity: 1, scale: 1, duration: 1 },
      '-=0.5'
    );

    return () => {
      tl.kill();
    };
  }, [reducedMotion]);

  const handleScrollTo = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const el = document.querySelector(href);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="hero"
      className="relative min-h-screen flex items-center overflow-hidden"
    >
      <MeshLinesBackground />

      <div
        ref={contentRef}
        className="relative z-10 max-w-[1200px] mx-auto w-full px-6 py-20 pt-32"
      >
        <div className="flex flex-col-reverse lg:flex-row items-center justify-between gap-12 lg:gap-8">
          {/* Text Content */}
          <div className="flex-1 max-w-xl">
            <div className={reducedMotion ? '' : 'opacity-0'}>
              <SectionLabel text="AI Automation Specialist" />
            </div>

            <h1
              className={`text-5xl md:text-6xl lg:text-7xl font-bold leading-[1.1] tracking-tight ${
                reducedMotion ? '' : 'opacity-0 hero-animate'
              }`}
            >
              <GradientText as="span">AI Automation</GradientText>
              <br />
              <span className="text-text-primary">Specialist</span>
            </h1>

            <p
              className={`mt-6 text-lg text-text-secondary leading-relaxed max-w-[540px] ${
                reducedMotion ? '' : 'opacity-0 hero-animate'
              }`}
            >
              I build AI-powered systems that automate repetitive work, streamline
              business operations, and help companies scale efficiently.
            </p>

            <div
              className={`flex flex-wrap gap-4 mt-10 ${
                reducedMotion ? '' : 'opacity-0 hero-animate'
              }`}
            >
              <a
                href="#projects"
                onClick={(e) => handleScrollTo(e, '#projects')}
                className="px-7 py-3.5 bg-violet hover:bg-violet-light text-white text-xs font-medium uppercase tracking-[0.08em] rounded-lg transition-all duration-300 hover:shadow-glow-violet hover:scale-[1.02]"
              >
                View Projects
              </a>
              <a
                href="#contact"
                onClick={(e) => handleScrollTo(e, '#contact')}
                className="px-7 py-3.5 border border-border-subtle hover:border-violet text-text-primary hover:text-white hover:bg-violet/5 text-xs font-medium uppercase tracking-[0.08em] rounded-lg transition-all duration-300 hover:scale-[1.02]"
              >
                Contact Me
              </a>
            </div>
          </div>

          {/* Profile Photo */}
          <div
            ref={photoRef}
            className={`flex-shrink-0 ${reducedMotion ? '' : 'opacity-0'}`}
          >
            <div className="relative animate-float">
              <div className="w-[280px] h-[280px] md:w-[360px] md:h-[360px] lg:w-[380px] lg:h-[380px] rounded-3xl overflow-hidden shadow-photo-glow animate-glow-pulse">
                <img
                  src="./assets/profile-photo.jpeg"
                  alt="Maheen Ansari — AI Automation Specialist"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Decorative ring */}
              <div className="absolute -inset-4 rounded-3xl border border-violet/20 pointer-events-none" />
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 z-10 hidden lg:flex flex-col items-center gap-2">
        <span className="text-xs text-text-muted uppercase tracking-widest">Scroll</span>
        <div className="w-px h-8 bg-gradient-to-b from-violet to-transparent" />
      </div>
    </section>
  );
}
