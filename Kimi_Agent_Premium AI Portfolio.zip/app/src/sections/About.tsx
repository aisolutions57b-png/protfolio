import { SectionLabel } from '@/components/SectionLabel';
import { GradientText } from '@/components/GradientText';
import { ScrollReveal } from '@/components/ScrollReveal';

export function About() {
  return (
    <section id="about" className="relative bg-bg py-24 lg:py-32">
      <div className="max-w-[1200px] mx-auto px-6">
        <div className="flex flex-col lg:flex-row gap-12 lg:gap-20">
          {/* Left Column - Heading */}
          <ScrollReveal className="lg:w-[40%]" variant="default">
            <div>
              <SectionLabel text="About" />
              <h2 className="text-4xl lg:text-5xl font-bold text-text-primary leading-tight">
                Turning Business Bottlenecks Into{' '}
                <GradientText>Intelligent Systems</GradientText>
              </h2>
            </div>
          </ScrollReveal>

          {/* Right Column - Description */}
          <ScrollReveal className="lg:w-[60%] lg:pt-12" variant="default" delay={0.2}>
            <p className="text-[17px] text-text-secondary leading-[1.8] max-w-[640px]">
              I help businesses eliminate repetitive work and improve operational
              efficiency through AI-powered automation. My focus is on solving real
              business problems by designing intelligent workflows that automate
              customer interactions, lead management, appointment scheduling, and
              internal operations.
            </p>
          </ScrollReveal>
        </div>
      </div>
    </section>
  );
}
