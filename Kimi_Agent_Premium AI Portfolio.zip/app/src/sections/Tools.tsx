import { SectionLabel } from '@/components/SectionLabel';
import { ScrollReveal } from '@/components/ScrollReveal';
import { cn } from '@/lib/utils';

const tools = [
  'n8n',
  'OpenAI API',
  'Apify',
  'Google Sheets',
  'Airtable',
  'Meta Developer Platform',
  'WhatsApp Business API',
];

function ToolBadge({ name }: { name: string }) {
  return (
    <span
      className={cn(
        'inline-block px-5 py-2.5 bg-surface border border-border-subtle rounded-lg',
        'text-sm text-text-secondary font-medium',
        'transition-all duration-300',
        'hover:border-violet hover:bg-violet/5 hover:text-text-primary',
        'cursor-default'
      )}
    >
      {name}
    </span>
  );
}

export function Tools() {
  return (
    <section id="tools" className="relative bg-bg py-16 lg:py-20">
      <div className="max-w-[1200px] mx-auto px-6 text-center">
        <ScrollReveal variant="default">
          <SectionLabel text="Tech Stack" centered />
          <h3 className="text-2xl lg:text-3xl font-bold text-text-primary mb-10">
            Tools & Technologies
          </h3>
        </ScrollReveal>

        <ScrollReveal variant="badge" stagger={0.08}>
          <div className="flex flex-wrap justify-center gap-3">
            {tools.map((tool) => (
              <ToolBadge key={tool} name={tool} />
            ))}
          </div>
        </ScrollReveal>
      </div>
    </section>
  );
}
