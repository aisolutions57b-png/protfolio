export function Footer() {
  return (
    <footer className="bg-bg border-t border-border-subtle">
      <div className="max-w-[1200px] mx-auto px-6 h-20 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-6">
          <span className="text-base font-semibold text-text-primary">
            Maheen Ansari
          </span>
          <span className="hidden sm:inline text-sm text-text-muted">
            Transforming business bottlenecks into intelligent AI systems.
          </span>
        </div>
        <span className="text-sm text-text-muted">
          &copy; 2026 All rights reserved.
        </span>
      </div>
    </footer>
  );
}
