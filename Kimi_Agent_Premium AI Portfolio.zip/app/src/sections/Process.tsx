import { useEffect, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { SectionLabel } from '@/components/SectionLabel';
import { GlassmorphismCard } from '@/components/GlassmorphismCard';
import { useReducedMotion } from '@/hooks/useReducedMotion';

gsap.registerPlugin(ScrollTrigger);

const steps = [
  {
    number: '01',
    title: 'Identify Bottlenecks',
    description:
      'Deep-dive analysis of your current workflows to pinpoint inefficiencies, manual tasks, and areas where automation can deliver maximum impact',
  },
  {
    number: '02',
    title: 'Design Intelligent Workflows',
    description:
      'Create detailed automation blueprints mapping out every step, decision point, and integration required for a seamless workflow',
  },
  {
    number: '03',
    title: 'Build AI Systems',
    description:
      'Develop and deploy production-ready automation systems using cutting-edge AI tools and no-code/low-code platforms',
  },
  {
    number: '04',
    title: 'Optimize & Scale',
    description:
      'Monitor performance, refine workflows based on real data, and scale your automation infrastructure as your business grows',
  },
];

export function Process() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const lineRef = useRef<HTMLDivElement>(null);
  const stepRefs = useRef<(HTMLDivElement | null)[]>([]);
  const cardRefs = useRef<(HTMLDivElement | null)[]>([]);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    if (reducedMotion || !sectionRef.current) return;

    const ctx = gsap.context(() => {
      // Timeline line draw animation
      if (lineRef.current) {
        gsap.fromTo(
          lineRef.current,
          { scaleY: 0 },
          {
            scaleY: 1,
            ease: 'none',
            scrollTrigger: {
              trigger: sectionRef.current,
              start: 'top 60%',
              end: 'bottom 60%',
              scrub: true,
            },
          }
        );
      }

      // Step circles and cards animations
      stepRefs.current.forEach((stepEl) => {
        if (stepEl) {
          gsap.fromTo(
            stepEl,
            { scale: 0, opacity: 0 },
            {
              scale: 1,
              opacity: 1,
              duration: 0.5,
              ease: 'back.out(1.7)',
              scrollTrigger: {
                trigger: stepEl,
                start: 'top 80%',
                toggleActions: 'play none none none',
              },
            }
          );
        }
      });

      cardRefs.current.forEach((cardEl, idx) => {
        if (cardEl) {
          const isLeft = idx % 2 === 0;
          gsap.fromTo(
            cardEl,
            { opacity: 0, x: isLeft ? -30 : 30 },
            {
              opacity: 1,
              x: 0,
              duration: 0.7,
              ease: 'power3.out',
              scrollTrigger: {
                trigger: cardEl,
                start: 'top 80%',
                toggleActions: 'play none none none',
              },
            }
          );
        }
      });
    }, sectionRef);

    return () => ctx.revert();
  }, [reducedMotion]);

  return (
    <section id="process" ref={sectionRef} className="relative bg-bg py-24 lg:py-32">
      <div className="max-w-[1000px] mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-20">
          <SectionLabel text="How I Work" centered />
          <h2 className="text-4xl lg:text-5xl font-bold text-text-primary">
            My Process
          </h2>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Vertical Line - Desktop: center, Mobile: left */}
          <div className="absolute left-6 lg:left-1/2 top-0 bottom-0 w-0.5">
            <div
              ref={lineRef}
              className="w-full h-full origin-top"
              style={{
                background:
                  'linear-gradient(180deg, #6C63FF 0%, #00D4FF 100%)',
                boxShadow: '0 0 20px rgba(108, 99, 255, 0.3)',
              }}
            />
          </div>

          {/* Steps */}
          <div className="space-y-12 lg:space-y-16">
            {steps.map((step, index) => {
              const isLeft = index % 2 === 0;
              return (
                <div
                  key={step.number}
                  className={`relative flex items-center ${
                    isLeft
                      ? 'lg:flex-row'
                      : 'lg:flex-row-reverse'
                  } flex-row`}
                >
                  {/* Card */}
                  <div
                    ref={(el) => { cardRefs.current[index] = el; }}
                    className={`ml-16 lg:ml-0 lg:w-[45%] ${
                      isLeft ? 'lg:mr-auto lg:pr-12' : 'lg:ml-auto lg:pl-12'
                    } ${reducedMotion ? '' : 'opacity-0'}`}
                  >
                    <GlassmorphismCard className="p-6">
                      <h3 className="text-xl font-semibold text-text-primary mb-2">
                        {step.title}
                      </h3>
                      <p className="text-sm text-text-secondary leading-relaxed">
                        {step.description}
                      </p>
                    </GlassmorphismCard>
                  </div>

                  {/* Step Circle */}
                  <div
                    ref={(el) => { stepRefs.current[index] = el; }}
                    className={`absolute left-6 lg:left-1/2 -translate-x-1/2 z-10 ${
                      reducedMotion ? '' : 'opacity-0'
                    }`}
                  >
                    <div className="w-12 h-12 rounded-full bg-surface border-2 border-violet flex items-center justify-center">
                      <span className="text-xs font-medium text-violet">
                        {step.number}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}
