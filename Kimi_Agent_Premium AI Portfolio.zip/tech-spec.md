# Technical Specification — Maheen Ansari AI Automation Portfolio

## Dependencies

### Production
| Package | Version | Purpose |
|---------|---------|---------|
| react | ^19.0 | UI framework |
| react-dom | ^19.0 | DOM renderer |
| three | ^0.170 | 3D engine for hero mesh-lines background |
| three.meshline | ^1.4 | MeshLine geometry for animated lines |
| gsap | ^3.12 | Animation engine + ScrollTrigger plugin |
| @fontsource/inter | ^5.0 | Self-hosted Inter font |
| @fontsource/jetbrains-mono | ^5.0 | Self-hosted JetBrains Mono font |
| lucide-react | ^0.460 | Icon library |

### Dev
| Package | Version | Purpose |
|---------|---------|---------|
| typescript | ^5.6 | Type safety |
| vite | ^7.2 | Build tool |
| @vitejs/plugin-react | ^4.3 | React plugin for Vite |
| tailwindcss | ^3.4 | Utility CSS |
| @types/three | ^0.170 | Three.js type definitions |

---

## Component Inventory

### shadcn/ui Components
| Component | Usage | Customization |
|-----------|-------|---------------|
| Button | CTA buttons (Primary/Secondary variants) | Custom colors matching design tokens |
| Card | Base for skill/project cards | Override with glassmorphism styles |
| Badge | Tool/technology badges | Custom dark theme styling |

### Custom Components — Sections
| Component | File | Description |
|-----------|------|-------------|
| Navigation | `sections/Navigation.tsx` | Fixed nav with scroll-triggered background change |
| Hero | `sections/Hero.tsx` | Full-viewport hero with Three.js canvas + content |
| About | `sections/About.tsx` | Two-column about section |
| Skills | `sections/Skills.tsx` | 3×2 skill cards grid |
| Tools | `sections/Tools.tsx` | Technology badges row |
| Projects | `sections/Projects.tsx` | 5 project cards in responsive grid |
| Process | `sections/Process.tsx` | 4-step animated timeline |
| Contact | `sections/Contact.tsx` | Business card style contact section |
| Footer | `sections/Footer.tsx` | Minimal footer |

### Custom Components — Reusable
| Component | File | Description |
|-----------|------|-------------|
| MeshLinesBackground | `components/MeshLinesBackground.tsx` | Three.js canvas with animated mesh lines (Core Effect) |
| SectionLabel | `components/SectionLabel.tsx` | Uppercase label with accent line |
| GradientText | `components/GradientText.tsx` | Text with gradient fill (white→violet→cyan) |
| GlassmorphismCard | `components/GlassmorphismCard.tsx` | Shared card with glassmorphism styling |
| ScrollReveal | `components/ScrollReveal.tsx` | GSAP ScrollTrigger wrapper for scroll animations |
| FloatingImage | `components/FloatingImage.tsx` | Image with float animation + glow |
| AnimatedGlow | `components/AnimatedGlow.tsx` | Pulsing glow effect |

### Custom Hooks
| Hook | File | Description |
|------|------|-------------|
| useScrollPosition | `hooks/useScrollPosition.ts` | Track scroll position for nav background transition |
| useReducedMotion | `hooks/useReducedMotion.ts` | Detect prefers-reduced-motion |

---

## Animation Implementation Table

| # | Animation | Library / Approach | Implementation | Complexity |
|---|-----------|-------------------|----------------|------------|
| 1 | **Mesh Lines Background** | Three.js + MeshLine | Custom component: PerspectiveCamera, WebGLRenderer with FilmPass post-processing. Lines spawn with random growth behaviors (Static, Moving, Square, Circle). Each line uses MeshLine geometry with custom MeshLineMaterial. FilmPass adds grain texture. | 🔒 High |
| 2 | **Hero Text Entrance** | GSAP timeline | On mount: staggered fade-in + translateY(30→0) for label, headline, subheadline, buttons. 0.15s stagger, 1s duration, power3.out | Low |
| 3 | **Hero Photo Entrance** | GSAP | Fade-in + scale(0.9→1), 0.5s delay, 1s duration | Low |
| 4 | **Hero Photo Float** | CSS @keyframes | translateY oscillates ±8px over 4s ease-in-out infinite. Applied via Tailwind arbitrary animation or inline style | Low |
| 5 | **Hero Glow Pulse** | CSS @keyframes | box-shadow opacity oscillates 0.2→0.4 over 3s. CSS animation on pseudo-element | Low |
| 6 | **Nav Scroll Transition** | React state + CSS | useScrollPosition hook toggles class at 100px scroll. CSS transition on background/border/backdrop-filter | Low |
| 7 | **Nav Link Underline** | CSS | ::after pseudo-element, scaleX(0→1) on hover, transform-origin left. 0.3s ease | Low |
| 8 | **Mobile Menu Overlay** | CSS + React state | Full-screen overlay, fade-in backdrop + slide-in panel. AnimatePresence for mount/unmount | Medium |
| 9 | **Section Scroll Reveal (default)** | GSAP ScrollTrigger | ScrollReveal wrapper: opacity 0→1, translateY(30→0), 0.8s, power3.out, start "top 80%". Reusable component | Low |
| 10 | **Card Scroll Reveal** | GSAP ScrollTrigger | opacity 0→1, translateY(40→0), scale(0.95→1), 0.6s, power2.out, stagger 0.15s | Low |
| 11 | **Badge Scroll Reveal** | GSAP ScrollTrigger | Fade-in + translateY(20→0), stagger 0.08s per badge | Low |
| 12 | **Card Hover Effects** | CSS | translateY(-4px), border-color transition to Border Glow, box-shadow. 0.4s cubic-bezier | Low |
| 13 | **Project Card Hover** | CSS | translateY(-8px), stronger glow, top accent bar shimmer (hue-rotate animation 3s linear infinite) | Low |
| 14 | **CTA Button Hover** | CSS | Scale(1.02), color lighten, glow box-shadow. 0.3s ease | Low |
| 15 | **Timeline Line Draw** | GSAP ScrollTrigger | scrub: true, height 0%→100% tied to scroll position through the Process section | Medium |
| 16 | **Timeline Step Circles** | GSAP ScrollTrigger | scale(0→1) with back.out(1.7) bounce as each step enters viewport | Low |
| 17 | **Timeline Step Cards** | GSAP ScrollTrigger | Left cards: translateX(-30→0), right cards: translateX(30→0), 0.7s | Low |
| 18 | **Contact Glow Pulse** | CSS @keyframes | Decorative radial-gradient opacity 0.05→0.1→0.05 over 4s | Low |
| 19 | **Top Accent Bar Shimmer** | CSS @keyframes | background-position shift creating shimmer, 3s linear infinite | Low |
| 20 | **Reduced Motion Fallback** | CSS + JS | useReducedMotion hook disables all GSAP and Three.js animations. Elements render in final state | Low |

---

## State & Logic Plan

### Three.js Lifecycle (MeshLinesBackground)

1. **Mount**: Initialize scene, camera, renderer, composer. Set clear color to #0B0F19. Append canvas to container ref.
2. **Animation loop** (requestAnimationFrame):
   - Update spawn timer, create new lines when threshold reached
   - For each alive line: push new points, update position, move forward, decrement dashOffset
   - Remove dead lines (dashOffset < -1)
   - Render via composer (includes FilmPass)
3. **Resize handler**: Update camera aspect, projection matrix, composer size
4. **Unmount**: Cancel animation frame, dispose geometries/materials, remove canvas
5. **Performance**: Lines array capped at ~50 active lines. On mobile: reduce spawn rate to 0.25, cap at 30 lines

### Scroll-Triggered Nav Background

- `useScrollPosition` hook reads `window.scrollY` via scroll event listener (throttled)
- Navigation component receives scroll position, toggles `scrolled` class at 100px threshold
- CSS handles the visual transition (background, backdrop-filter, border-bottom)

### GSAP ScrollTrigger Setup

- Single master approach: `ScrollReveal` component wraps children, accepts `variant` prop ("default", "card", "badge", "timeline-left", "timeline-right")
- Each variant maps to specific GSAP animation parameters
- All ScrollTriggers registered in App.tsx cleanup on unmount
- `scrub: true` used only for timeline line draw

### Responsive Behavior

- Breakpoints: sm(640), md(768), lg(1024), xl(1280)
- Hero: lg+ = two-column, below = single column (image above text)
- Skills grid: lg = 3×2, md = 2×3, sm = 1×6
- Projects grid: lg = 3-col (2+3), md = 2-col, sm = 1-col
- Process timeline: lg = alternating left/right, below = single column with line on left
- Navigation: lg+ = horizontal links, below = hamburger menu

---

## Other Key Decisions

### Font Loading
- Use `@fontsource/inter` (weights 400, 500, 600, 700) and `@fontsource/jetbrains-mono` (weight 400)
- Import in main.tsx for self-hosted loading (no external requests)
- Configure Tailwind fontFamily: sans → Inter, mono → JetBrains Mono

### Three.js Post-Processing
- Use `three/examples/jsm/postprocessing/EffectComposer`
- `RenderPass` + `FilmPass` (noiseIntensity 0.35, scanlinesIntensity 0.55, scanlinesCount 2048, grayscale)
- FilmPass adds subtle grain that elevates the premium feel

### Asset Strategy
- Profile photo: Copy from upload to public/assets/, reference via standard img tag or background-image
- No other external images needed (icons from Lucide, backgrounds are CSS gradients or Three.js)

### Build Output
- Static SPA deployed as single-page site
- All sections on one page with anchor navigation
- GSAP ScrollToPlugin for smooth anchor scrolling

### Accessibility Checklist
- prefers-reduced-motion: Disable Three.js animation + all GSAP animations
- Color contrast: Text Secondary (#8B95A8) on #0B0F19 = 5.8:1 ✓ (WCAG AA)
- Semantic HTML: nav, main, section, article, footer, h1-h3 hierarchy
- Focus states: Visible focus rings on all interactive elements (2px Primary Accent outline)
- Alt text on profile photo: "Maheen Ansari — AI Automation Specialist"
